#include <stdio.h>
#include "stm32f10x_gpio.h" 
#include "stm32f10x_exti.h"
#include "stm32f10x_rcc.h"
#include "delay.h"
#include "mpui2c.h"
#include "mpu9250.h"

/* ����MPU9250�ڲ���ַ����ؼĴ��� */
#define MPU6500_PWR_MGMT_1    0x6B  // ��Դ����������ֵ��0x00(��������)
#define MPU6500_PWR_MGMT_2    0x6C  // ��Դ����������ֵ��0x00(��������)
#define MPU6500_SMPLRT_DIV    0x19  // �����ǲ����ʣ�����ֵ��0x07(125Hz)
#define MPU6500_CONFIG        0x1A  // ��ͨ�˲�Ƶ�ʣ�����ֵ��0x06(5Hz)
#define MPU6500_GYRO_CONFIG   0x1B  // �������Լ켰������Χ������ֵ��0x18(���Լ죬2000deg/s)
#define MPU6500_ACCEL_CONFIG  0x1C  // ���ټ��Լ졢������Χ����ͨ�˲�Ƶ�ʣ�����ֵ��0x01(���Լ죬2G��5Hz)

#define MPU6500_WHO_AM_I      0x75  // ����ID��ѯ
#define MPU6500_DEVICE_ID     0x71  // ��MPU9250��, ����ID=0x71
#define MPU6500_USER_CTRL     0x6A  // �û����õ�Ϊ0x10ʱʹ��SPIģʽ

#define MPU6500_INT_PIN_CFG   0x37

#define MPU6500_I2C_ADDR      0x68
#define AK8963_I2C_ADDR       0x0C

// [0] accel_x_hi [1] accel_x_lo
// [2] accel_y_hi [3] accel_y_lo
// [4] accel_z_hi [5] accel_z_lo
// [6] temp_hi    [7] temp_lo
// [8] gyro_x_hi  [9] gyro_x_lo
// [10] gyro_y_hi [11] gyro_y_lo
// [12] gyro_z_hi [13] gyro_z_lo
#define MPU6500_DATA_START    0x3B
 
// [0] mag_x_lo [1] mag_x_hi
// [2] mag_y_lo [3] mag_y_hi
// [4] mag_z_lo [5] mag_z_hi
#define AK8963_DATA_START     0x03

/* ����MPU9250 ������,���ٶȼƺʹ������������ */
#define G2MSS (9.86) // gתm*s^-2
#define UT2MGS (10.0) // uTתmGs, 10000GS(��˹)����1T(��˹��), �شų�ԼΪ0.6Gs
#define DEG2RAD (3.14159265358979323846 / 180.0) //deg/sתrad/s 

// ����������
#define MPU9250_GYRO_FS_250DPS    0x00
#define MPU9250_GYRO_FS_500DPS    0x08
#define MPU9250_GYRO_FS_1000DPS   0x10
#define MPU9250_GYRO_FS_2000DPS   0x18
// �����ǲ���Ƶ��
// | LPF | BandW | Delay  | Sample |
// +-----+-------+--------+--------+
// |  0  | 256Hz | 0.98ms |  8kHz  |
// |  1  | 188Hz |  1.9ms |  1kHz  |
// |  2  |  98Hz |  2.8ms |  1kHz  |
// |  3  |  42Hz |  4.8ms |  1kHz  |
// |  4  |  20Hz |  8.3ms |  1kHz  |
// |  5  |  10Hz | 13.4ms |  1kHz  |
// |  6  |   5Hz | 18.6ms |  1kHz  |
// |  7  | -- Reserved -- |  8kHz  |
#define MPU9250_GYRO_LPS_250HZ    0x00
#define MPU9250_GYRO_LPS_184HZ    0x01
#define MPU9250_GYRO_LPS_92HZ     0x02
#define MPU9250_GYRO_LPS_41HZ     0x03
#define MPU9250_GYRO_LPS_20HZ     0x04
#define MPU9250_GYRO_LPS_10HZ     0x05
#define MPU9250_GYRO_LPS_5HZ      0x06
#define MPU9250_GYRO_LPS_DISABLE  0x07
// ������������ϵ��
#define MPU9250_GYRO_STY_250DPS   ((float)0.007633587786f) // 0.007633587786 dps/LSB
#define MPU9250_GYRO_STY_500DPS   ((float)0.015267175572f) // 0.015267175572 dps/LSB
#define MPU9250_GYRO_STY_1000DPS  ((float)0.030487804878f) // 0.030487804878 dps/LSB
#define MPU9250_GYRO_STY_2000DPS  ((float)0.060975609756f) // 0.060975609756 dps/LSB

// ���ٶȼ�����
#define MPU9250_ACCEL_FS_2G     0x00
#define MPU9250_ACCEL_FS_4G     0x08
#define MPU9250_ACCEL_FS_8G     0x10
#define MPU9250_ACCEL_FS_16G    0x18
// ���ٶȼƲ���Ƶ��
//  | LPF | BandW | Delay  | Sample |
//  +-----+-------+--------+--------+
//  |  0  | 260Hz |    0ms |  1kHz  |
//  |  1  | 184Hz |  2.0ms |  1kHz  |
//  |  2  |  94Hz |  3.0ms |  1kHz  |
//  |  3  |  44Hz |  4.9ms |  1kHz  |
//  |  4  |  21Hz |  8.5ms |  1kHz  |
//  |  5  |  10Hz | 13.8ms |  1kHz  |
//  |  6  |   5Hz | 19.0ms |  1kHz  |
//  |  7  | -- Reserved -- |  1kHz  |
#define MPU9250_ACCEL_LPS_460HZ   0x00
#define MPU9250_ACCEL_LPS_184HZ   0x01
#define MPU9250_ACCEL_LPS_92HZ    0x02
#define MPU9250_ACCEL_LPS_41HZ    0x03
#define MPU9250_ACCEL_LPS_20HZ    0x04
#define MPU9250_ACCEL_LPS_10HZ    0x05
#define MPU9250_ACCEL_LPS_5HZ     0x06
#define MPU9250_ACCEL_LPS_DISABLE 0x08
// ���ٶȼ�������ϵ��
#define MPU9250_ACCEL_STY_2G       ((float)0.000061035156f) // 0.000061035156 g/LSB
#define MPU9250_ACCEL_STY_4G       ((float)0.000122070312f) // 0.000122070312 g/LSB
#define MPU9250_ACCEL_STY_8G       ((float)0.000244140625f) // 0.000244140625 g/LSB
#define MPU9250_ACCEL_STY_16G      ((float)0.000488281250f) // 0.000488281250 g/LSB

// �¶ȼ�����ϵ��
#define MPU9250_TEMP_STY_85DEGC    ((float)0.002995177763f) // 0.002995177763 degC/LSB

// ������������ϵ��
#define MPU9250_MAG_STY_4800UT    ((float)0.6f)            // 0.6 uT/LSB


/* ������,���ٶȼƺʹ��������̼������� */
u8 CUR_GYRO_FS = MPU9250_GYRO_FS_1000DPS;
u8 CUR_GYRO_LPS = MPU9250_GYRO_LPS_184HZ;
u8 CUR_ACCEL_FS = MPU9250_ACCEL_FS_4G;
u8 CUR_ACCEL_LPS = MPU9250_ACCEL_LPS_184HZ;
float CUR_GYRO_STY = MPU9250_GYRO_STY_1000DPS;
float CUR_ACCEL_STY = MPU9250_ACCEL_STY_4G;
float CUR_TEMP_STY = MPU9250_TEMP_STY_85DEGC;
float CUR_MAG_STY = MPU9250_MAG_STY_4800UT;
int gyro_bias_x = 0;
int gyro_bias_y = 0;
int gyro_bias_z = 0;
float mag_adjust_x = 1.0f;
float mag_adjust_y = 1.0f;
float mag_adjust_z = 1.0f;
u8 mag_bias_x = 0;
u8 mag_bias_y = 0;
u8 mag_bias_z = 0;

u8 mpu_9250_write(u8 addr, u8 reg, u8 len, u8 *buf) {
  u8 i; 
  mpu_i2c_start(); 
  mpu_i2c_send_byte((addr<<1)|0); // ����������ַ+д��־0
  if (mpu_i2c_wait_ack()) { // �ȴ�Ӧ��
    mpu_i2c_stop(); 
    return 1;
  }
  mpu_i2c_send_byte(reg); // д�Ĵ�����ַ
  mpu_i2c_wait_ack(); // �ȴ�Ӧ��
  for (i = 0; i < len; i++) {
    mpu_i2c_send_byte(buf[i]); // ��������
    if (mpu_i2c_wait_ack()) { // �ȴ�ACK
      mpu_i2c_stop();
      return 1;
    }
  }
  mpu_i2c_stop();
  return 0;
} 

u8 mpu_9250_read(u8 addr,u8 reg,u8 len,u8 *buf) {
  mpu_i2c_start(); 
  mpu_i2c_send_byte((addr<<1)|0);// ����������ַ+д��־0
  if (mpu_i2c_wait_ack()) { // �ȴ�Ӧ��
    mpu_i2c_stop();
    return 1;
  }
  mpu_i2c_send_byte(reg); // д�Ĵ�����ַ
  mpu_i2c_wait_ack(); // �ȴ�Ӧ��
  mpu_i2c_start();
  mpu_i2c_send_byte((addr << 1) | 1); // ����������ַ+����־1
  mpu_i2c_wait_ack(); // �ȴ�Ӧ�� 
  while (len) {
    if (len == 1) *buf = mpu_i2c_read_byte(0); // ������,����nACK 
    else *buf = mpu_i2c_read_byte(1); // ������,����ACK  
    len--;
    buf++; 
  }    
  mpu_i2c_stop(); // ����һ��ֹͣ���� 
  return 0;
}

void EXTI1_IRQHandler(void){
  EXTI_ClearITPendingBit(EXTI_Line1);
}

void mpu_9250_exti_config(void) {
  GPIO_InitTypeDef GPIO_InitStructure;
  NVIC_InitTypeDef NVIC_InitStructure;
  EXTI_InitTypeDef EXTI_InitStructure;

  RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_Init(GPIOB, &GPIO_InitStructure);

  GPIO_EXTILineConfig(GPIO_PortSourceGPIOA,GPIO_PinSource1);
  EXTI_InitStructure.EXTI_Line = EXTI_Line1;
  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
  EXTI_Init(&EXTI_InitStructure);

  NVIC_InitStructure.NVIC_IRQChannel = EXTI1_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x00;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x00;
  NVIC_Init(&NVIC_InitStructure);
}

u8 mpu_9250_work_config(void) {
  u8 reg_value = 0x00;
  u8 ret_code = mpu_9250_write(MPU6500_I2C_ADDR, MPU6500_PWR_MGMT_1, 1, &reg_value); // �������״̬
  if (ret_code) {
    return 1;
  }
  delay_ms(100);
  ret_code = mpu_9250_read(MPU6500_I2C_ADDR, MPU6500_WHO_AM_I, 1, &reg_value);
  if (ret_code) {
    return 1;
  }
  if (reg_value != MPU6500_DEVICE_ID) {
    return 2;
  }
  delay_ms(1000);

  reg_value = 0x00;
  ret_code = mpu_9250_write(MPU6500_I2C_ADDR, MPU6500_PWR_MGMT_2, 1, &reg_value); // ʹ�ܼĴ���X, Y, Z���ٶ�
  if (ret_code) {
    return 1;
  }

  reg_value = 0x07;
  ret_code = mpu_9250_write(MPU6500_I2C_ADDR, MPU6500_SMPLRT_DIV, 1, &reg_value); // ���ò���Ƶ��
  if (ret_code) {
    return 1;
  }

  reg_value = 0x06;
  ret_code = mpu_9250_write(MPU6500_I2C_ADDR, MPU6500_CONFIG, 1, &reg_value); // ���õ�ͨ�˲�Ƶ��
  if (ret_code) {
    return 1;
  }

  reg_value = CUR_GYRO_FS | CUR_GYRO_LPS;
  ret_code = mpu_9250_write(MPU6500_I2C_ADDR, MPU6500_GYRO_CONFIG, 1, &reg_value); // ��������������
  if (ret_code) {
    return 1;
  }

  reg_value = 0x00;
  ret_code = mpu_9250_write(MPU6500_I2C_ADDR, MPU6500_USER_CTRL, 1, &reg_value); // ��ʼ��IIC
  if (ret_code) {
    return 1;
  }

  reg_value = CUR_ACCEL_FS | CUR_ACCEL_LPS;
  ret_code = mpu_9250_write(MPU6500_I2C_ADDR, MPU6500_ACCEL_CONFIG, 1, &reg_value); // ���ü��ٶȼ�����
  if (ret_code) {
    return 1;
  }

  reg_value = 0x02;
  ret_code = mpu_9250_write(MPU6500_I2C_ADDR, MPU6500_INT_PIN_CFG, 1, &reg_value); // ����bypassģʽ, ���ƴ�����
  if (ret_code) {
    return 1;
  }

  return 0;
}

u8 mpu_9250_read_accel_gyro_raw(short *raw_ax, short *raw_ay, short *raw_az, short *raw_gx, short *raw_gy, short *raw_gz) {
  u8 tmp_buf[14];

  // read accel and gyro data
  if (mpu_9250_read(MPU6500_I2C_ADDR, MPU6500_DATA_START, 14, tmp_buf)) {
    return 1;
  }

  *raw_ax = (((short)tmp_buf[0]) << 8) | (short)tmp_buf[1];
  *raw_ay = (((short)tmp_buf[2]) << 8) | (short)tmp_buf[3];
  *raw_az = (((short)tmp_buf[4]) << 8) | (short)tmp_buf[5];
  *raw_gx = (((short)tmp_buf[8]) << 8) | (short)tmp_buf[9];
  *raw_gy = (((short)tmp_buf[10]) << 8) | (short)tmp_buf[11];
  *raw_gz = (((short)tmp_buf[12]) << 8) | (short)tmp_buf[13];

  return 0;
}

u8 mpu_9250_read_mag_raw(short *raw_mx, short *raw_my, short *raw_mz) {
  u8 tmp_buf[6];
  
  // turn on bypass mode and read mag data
  u8 reg_value = 0x01;
  if (mpu_9250_write(AK8963_I2C_ADDR, 0x0A, 1, &reg_value)) {
    return 1;
  }

  delay_ms(10);

  if (mpu_9250_read(AK8963_I2C_ADDR, AK8963_DATA_START, 6, tmp_buf)) {
    return 1;
  }
  
  *raw_mx = (((short)tmp_buf[1]) << 8) | (short)tmp_buf[0];
  *raw_my = (((short)tmp_buf[3]) << 8) | (short)tmp_buf[2];
  *raw_mz = (((short)tmp_buf[5]) << 8) | (short)tmp_buf[4];

  return 0;
}

u8 mpu_9250_calibrate() {
  int i;
  u8 reg_value;
  u8 tmp_x, tmp_y, tmp_z;
  for (i = 0; i < 15; i++) {
    short raw_ax, raw_ay, raw_az, raw_gx, raw_gy, raw_gz;
    if (mpu_9250_read_accel_gyro_raw(&raw_ax, &raw_ay, &raw_az, &raw_gx, &raw_gy, &raw_gz)) {
      goto ERROR;
    }
    if (i >= 5) {
      gyro_bias_x += raw_gx;
      gyro_bias_y += raw_gy;
      gyro_bias_z += raw_gz;
    }
  }
  gyro_bias_x /= 10;
  gyro_bias_y /= 10;
  gyro_bias_z /= 10;
  
  reg_value = 0x01;
  if (mpu_9250_write(AK8963_I2C_ADDR, 0x0A, 1, &reg_value)) {
    return 1;
  }

  delay_ms(10);
  
  if (mpu_9250_read(AK8963_I2C_ADDR, 0x10, 1, &tmp_x) ) {
    goto ERROR;
  }
  
  if (mpu_9250_read(AK8963_I2C_ADDR, 0x11, 1, &tmp_y) ) {
    goto ERROR;
  }
  
  if (mpu_9250_read(AK8963_I2C_ADDR, 0x12, 1, &tmp_z) ) {
    goto ERROR;
  }
  
  mag_adjust_x = (float)(tmp_x - 128)/256.0f + 1.0f;   // return x-axis sensitivity adjustment values, etc.
  mag_adjust_y = (float)(tmp_y - 128)/256.0f + 1.0f;  
  mag_adjust_z = (float)(tmp_z - 128)/256.0f + 1.0f;
  
  printf("gyro bias: %d, %d, %d\n", gyro_bias_x, gyro_bias_y, gyro_bias_z);
  printf("mag adjust: %d, %d, %d->%f, %f, %f\n", tmp_x, tmp_y, tmp_z, mag_adjust_x, mag_adjust_y, mag_adjust_z);

  return 0;
  
ERROR:
  gyro_bias_x = 0;
  gyro_bias_x = 0;
  gyro_bias_x = 0;
  mag_bias_x = 0;
  mag_bias_x = 0;
  mag_bias_x = 0;
  return 1; 
}

u8 mpu_9250_is_dry(void) {
  return GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8) == Bit_SET ? 1 : 0;
}

u8 mpu_9250_read_accel_gyro(float *ax, float *ay, float *az, float *gx, float *gy, float *gz) {
  short raw_ax, raw_ay, raw_az, raw_gx, raw_gy, raw_gz;
  if (mpu_9250_read_accel_gyro_raw(&raw_ax, &raw_ay, &raw_az, &raw_gx, &raw_gy, &raw_gz)) {
    return 1;
  }
  *ax = (float)raw_ax * (CUR_ACCEL_STY * G2MSS);
  *ay = (float)raw_ay * (CUR_ACCEL_STY * G2MSS);
  *az = (float)raw_az * (CUR_ACCEL_STY * G2MSS);
  *gx = (float)(raw_gx - gyro_bias_x) * (CUR_GYRO_STY * DEG2RAD);
  *gy = (float)(raw_gy - gyro_bias_y) * (CUR_GYRO_STY * DEG2RAD);
  *gz = (float)(raw_gz - gyro_bias_z) * (CUR_GYRO_STY * DEG2RAD);
  return 0;
}

u8 mpu_9250_read_mag(float *mx, float *my, float *mz) {
  short raw_mx, raw_my, raw_mz;
  if (mpu_9250_read_mag_raw(&raw_mx, &raw_my, &raw_mz)) {
    return 1;
  }
  *mx = (float)raw_mx * mag_adjust_x * (CUR_MAG_STY * UT2MGS);
  *my = (float)raw_my * mag_adjust_y * (CUR_MAG_STY * UT2MGS);
  *mz = (float)raw_mz * mag_adjust_z * (CUR_MAG_STY * UT2MGS);
  return 0;
}

u8 mpu_9250_init(void) {
  u8 ret_code;
  mpu_i2c_init();
  mpu_9250_exti_config();
  ret_code = mpu_9250_work_config();
  if (ret_code) {
    return ret_code;
  }
  return mpu_9250_calibrate();
}
