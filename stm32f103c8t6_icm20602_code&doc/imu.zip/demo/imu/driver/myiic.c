#include "myiic.h"
#include "gpio.h"





//#define I2C_IO_DEBUG	1

uint8_t myiic_fast_mode = 1;



//void myiic_delay()
//{
//    uint8_t  i;
//	if(myiic_fast_mode)	i = 3;		//500k
//	else			i = 50;	//150k
//	
//    while (i)i--;
//}





//void myiic_init()
//{
//	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
//	gpio_mode_out(GPIOB,GPIO_Pin_6|GPIO_Pin_7);	//SCL
//	
//	MYIIC_SCL = 0;
//	MYIIC_SDAO = 1;
//}



//void myiic_start()
//{
//	MYIIC_SDAO = 1;	myiic_delay();
//	MYIIC_SCL = 1;	myiic_delay();
//	
//	MYIIC_SDAO = 0;	//������
//	
//	myiic_delay(); 	MYIIC_SCL = 0;	
//}


//void myiic_stop()
//{
//	myiic_delay();
//	MYIIC_SDAO = 0;
//	myiic_delay();
//	MYIIC_SCL = 1;
//	myiic_delay();
//	MYIIC_SDAO = 1;
//	myiic_delay();
//	MYIIC_SCL = 0;
//	
//}
//uint8_t myiic_wait_ack()
//{
//	uint16_t t=0;
//	
//	MYIIC_SDA_MODE_IN();
//	myiic_delay();myiic_delay();
//	MYIIC_SCL = 1;
//	myiic_delay();
//	while(MYIIC_SDAI)
//	{
//		if(++t>1000)
//		{
//			myiic_stop();
//			
//#if I2C_IO_DEBUG
//			printf("I2C_IO ACK_ERROR\r\n");
//			//printf("I2C_IO ACK_ERROR,address=0x%2x(%d)\r\n",slave_address(),slave_address());
//#endif
//			return 1;
//		}
//	}
//	myiic_delay();
//	MYIIC_SCL = 0;
//	MYIIC_SDA_MODE_OUT();
//	return 0;	
//}

//void myiic_ack()
//{
//	
//	MYIIC_SDAO = 0;
//	myiic_delay();
//	MYIIC_SCL = 1;		//SDA ���ֵ͵�ƽ
//	myiic_delay();
//	myiic_delay();
//	MYIIC_SCL = 0;		
//}


//void myiic_nack()
//{
//	myiic_delay();
//	MYIIC_SDAO = 1;	
//	myiic_delay();	
//	
//	MYIIC_SCL = 1;			//SDA �ߵ�ƽ
//	myiic_delay();
//	myiic_delay();
//	MYIIC_SCL = 0;		
//}


//void myiic_write_byte(uint8_t c)
//{
//	uint8_t i;
//	for(i=0;i<8;i++)
//	{
//		myiic_delay();		
//		
//		MYIIC_SDAO = (c&0x80)>>7;
//		
//		myiic_delay();		
//		
//		MYIIC_SCL = 1;
//		myiic_delay();		
//		myiic_delay();
//		
//		MYIIC_SCL = 0;
//		c <<=1;
//	}	
//}


//uint8_t myiic_read_byte()
//{
//	uint8_t val,i;
//	
//	MYIIC_SDA_MODE_IN();
//	
//	for(i = 0;i<8;i++)
//	{	
//		myiic_delay();myiic_delay();	
//		
//		val<<=1;	
//		MYIIC_SCL = 1;
//		myiic_delay();	
//		if(MYIIC_SDAI)val++;
//		myiic_delay();	
//		
//		MYIIC_SCL=0;
//	}
//	myiic_delay();
//	MYIIC_SDA_MODE_OUT();
//	return val;	
//}



//void myiic_delay(void)			//����ͨ�������ɽ����ٶ����Ĵ˺���
//{
//    uint8_t  i = 7;//��������Ż��ٶ�	����������͵�5����д��
//    while (i)i--;
//}



//void myiic_init(void)
//{
//	//�ȳ�ʼ��SCL�ڳ�ʼ��SDAû����,�ȳ�ʼ��SDA,SCL������!!!
//	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
//	gpio_mode_out(GPIOB,GPIO_Pin_6);	//SCL
//	gpio_mode_out(GPIOB,GPIO_Pin_7);	//SCL
//	
//	MYIIC_SCL = 0;
//	MYIIC_SDAO = 1;
//										
//}






//void myiic_start(void)
//{	
//	MYIIC_SDAO = 1;
//	MYIIC_SCL = 1;
//	myiic_delay();
//	MYIIC_SDAO = 0;	//�½���
//	myiic_delay();
//	MYIIC_SCL = 0;	
//}



//void myiic_stop(void)
//{
//	MYIIC_SDAO = 0;
//	MYIIC_SCL = 1;
//	myiic_delay();
//	MYIIC_SDAO = 1;
//	myiic_delay();
//	MYIIC_SCL = 0;
//}

//uint8_t myiic_wait_ack(void)
//{
//	uint8_t t=0;
//	MYIIC_SDA_MODE_IN();
//	MYIIC_SCL = 1;	
//	myiic_delay();
//	while(MYIIC_SDAI)
//	{
//		if(++t>250)
//		{
//			myiic_stop();
//			return 1;
//		}
//	}
//	myiic_delay();
//	MYIIC_SCL = 0;
//	MYIIC_SDA_MODE_OUT();
//	return 0;

//}

//void myiic_ack(void)
//{
//	MYIIC_SDAO = 0;
//	MYIIC_SCL = 1;		//SDA ���ֵ͵�ƽ
//	myiic_delay();
//	MYIIC_SCL = 0;	
//}

//void myiic_nack(void)
//{
//	MYIIC_SDAO = 1;		
//	MYIIC_SCL = 1;			//SDA �ߵ�ƽ
//	myiic_delay();
//	MYIIC_SCL = 0;		
//}


//void myiic_write_byte(uint8_t byte)
//{
//	uint8_t i;
//	for(i=0;i<8;i++)
//	{
//		MYIIC_SDAO = (byte&0x80)>>7;
//		MYIIC_SCL = 1;
//		myiic_delay();
//		MYIIC_SCL = 0;
//		myiic_delay();	
//		byte <<=1;
//	}
//}


//uint8_t myiic_read_byte()
//{	
//	uint8_t val,i;
//	MYIIC_SDA_MODE_IN();
//	for(i = 0;i<8;i++)
//	{	
//		val<<=1;	
//		MYIIC_SCL = 1;
//		myiic_delay();	
//		if(MYIIC_SDAI)val++;
//		MYIIC_SCL=0;
//		myiic_delay();	
//	}
//	MYIIC_SDA_MODE_OUT();
//	
//	return val;
//}


//===========================================================================
//дһ���ֽ�
//uint8_t myiic_writebyte(uint8_t slave_addr,uint8_t c)
//{
//	myiic_start();
//	
//	myiic_write_byte(slave_addr&0xfe);
//	if(myiic_wait_ack())return 1;
//	
//	myiic_write_byte(c);
//	if(myiic_wait_ack())return 1;
//	
//	myiic_stop();
//	return 0;
//}


////дһ������
//uint8_t myiic_write_buffer(uint8_t slave_addr, void *buf,uint16_t len)
//{
//	uint8_t *p;
//	uint16_t i;
//	myiic_start();
//	
//	myiic_write_byte(slave_addr&0xfe);
//	if(myiic_wait_ack())return 1;
//	
//	p  = (uint8_t*)buf;
//	for( i=0;i<len;i++)
//	{
//		myiic_write_byte(*p++);
//		if(myiic_wait_ack())return 1;
//	}
//	myiic_stop();
//	return 0;

//}


////��Ĵ���дһ���ֽ�
//uint8_t myiic_write_reg(uint8_t slave_addr,uint8_t reg_addr,uint8_t reg_val)
//{
//	myiic_start();
//	
//	myiic_write_byte(slave_addr&0xfe);
//	if(myiic_wait_ack())return 1;
//	
//	myiic_write_byte(reg_addr);
//	if(myiic_wait_ack())return 1;
//	
//	myiic_write_byte(reg_val);
//	if(myiic_wait_ack())return 1;
//	
//	myiic_stop();
//	return 0;
//}




////��Ĵ���дһ������
//uint8_t myiic_write_reg_buffer(uint8_t slave_addr,uint8_t reg_addr, void *buf,uint16_t len)
//{
//	uint8_t *p;
//	uint16_t i;
//	myiic_start();
//	
//	myiic_write_byte(slave_addr&0xfe);
//	if(myiic_wait_ack())return 1;
//	
//	myiic_write_byte(reg_addr);
//	if(myiic_wait_ack())return 1;
//	
//	 p = (uint8_t*)buf;
//	for(i=0;i<len;i++)
//	{
//		myiic_write_byte(*p++);
//		if(myiic_wait_ack())return 1;
//	}
//	
//	myiic_stop();
//	return 0;
//}




////��һ���ֽ�
//uint8_t myiic_readbyte(uint8_t slave_addr)
//{
//	uint8_t reg_val;
//	myiic_start();
//	
//	myiic_write_byte(slave_addr|0x01);
//	if(myiic_wait_ack())
//	{
//		return 0;
//	}
//	reg_val = myiic_read_byte();
//	myiic_stop();
//	
//	return reg_val;
//}

////��һ������
//uint8_t myiic_read_buffer(uint8_t slave_addr,void *buf,uint16_t len)
//{
//	uint8_t *p = buf;
//	uint16_t i;
//	myiic_start();
//	
//	myiic_write_byte(slave_addr|0x01);
//	if(myiic_wait_ack())return 1;
//	
//	p  = (uint8_t*)buf;
//	for( i=0;i<len;i++)
//	{
//		*p++ = myiic_read_byte();
//		myiic_ack();
//	}
//	
//	myiic_stop();
//	return 0;
//}


////�ӼĴ�����һ���ֽ�
//uint8_t myiic_read_reg(uint8_t slave_addr,uint8_t reg_addr)
//{
//	uint8_t reg_val;
//	myiic_start();
//	
//	
//	myiic_write_byte(slave_addr&0xfe);
//	if(myiic_wait_ack())
//	{
//		return 0;
//	}
//	
//	
//	myiic_write_byte(reg_addr);
//	if(myiic_wait_ack())	
//	{
//		return 0;
//	}
//	
//	myiic_start();
//	myiic_write_byte(slave_addr|0x01);
//	if(myiic_wait_ack())
//	{
//		return 0;
//	}
//	
//	reg_val = myiic_read_byte();
//	myiic_stop();
//	
//	return reg_val;
//}



////�ӼĴ�����һ������
//uint8_t myiic_read_reg_buffer(uint8_t slave_addr,uint8_t reg_addr,void *buf,uint16_t len)
//{
//	uint8_t *p = buf;
//	uint16_t i;
//	if(len == 0)return 0;
//	
//	myiic_start();
//	myiic_write_byte(slave_addr&0xfe);
//	if(myiic_wait_ack())
//	{
//		myiic_stop();
//		return 1;
//	}
//	
//	myiic_write_byte(reg_addr);
//	if(myiic_wait_ack())return 1;
//	
//	myiic_start();
//	myiic_write_byte(slave_addr|0x01);
//	if(myiic_wait_ack())return 1;
//	

//	p  = (uint8_t*)buf;
//	for( i=0;i<len-1;i++)
//	{
//		*p++ = myiic_read_byte();
//		myiic_ack();
//	}
//	
//	*p = myiic_read_byte();
//	myiic_ack();
//	
//	myiic_stop();
//	return 0;
//}



void IIC_delay(void)			//����ͨ�������ɽ����ٶ����Ĵ˺���
{
    uint8_t  i = 7;//��������Ż��ٶ�	����������͵�5����д��
    while (i)i--;
}



void IIC_Init(void)
{
	//�ȳ�ʼ��SCL�ڳ�ʼ��SDAû����,�ȳ�ʼ��SDA,SCL������!!!
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	gpio_mode_out(GPIOB,GPIO_Pin_6|GPIO_Pin_7);	//SCL															//SDA
}






void IIC_Start(void)
{	
	IIC_SDA = 1;
	IIC_SCL = 1;
	IIC_delay();
	IIC_SDA = 0;	//�½���
	IIC_delay();
	IIC_SCL = 0;	
}



void IIC_Stop(void)
{
	IIC_SDA = 0;
	IIC_SCL = 1;
	IIC_delay();
	IIC_SDA = 1;
	IIC_delay();
	IIC_SCL = 0;
}

uint8_t IIC_WaitAck(void)
{
	uint8_t t=0;
	IIC_SDA_IN();
	IIC_SCL = 1;	
	IIC_delay();
	while(IIC_SDAI)
	{
		if(++t>250)
		{
			IIC_Stop();
			return 1;
		}
	}
	IIC_delay();
	IIC_SCL = 0;
	IIC_SDA_OUT();
	return 0;

}

void IIC_Ack(void)
{
	IIC_SDA = 0;
	IIC_SCL = 1;		//SDA ���ֵ͵�ƽ
	IIC_delay();
	IIC_SCL = 0;	
}

void IIC_NAck(void)
{
	IIC_SDA = 1;		
	IIC_SCL = 1;			//SDA �ߵ�ƽ
	IIC_delay();
	IIC_SCL = 0;		
}


void IIC_WriteByte(uint8_t byte)
{
	uint8_t i;
	for(i=0;i<8;i++)
	{
		IIC_SDA = (byte&0x80)>>7;
		IIC_SCL = 1;
		IIC_delay();
		IIC_SCL = 0;
		IIC_delay();	
		byte <<=1;
	}
}


uint8_t IIC_ReadByte(uint8_t ack)
{	
	uint8_t val,i;
	IIC_SDA_IN();
	for(i = 0;i<8;i++)
	{	
		val<<=1;	
		IIC_SCL = 1;
		IIC_delay();	
		if(IIC_SDAI)val++;
		IIC_SCL=0;
		IIC_delay();	
	}
	IIC_SDA_OUT();
	if(ack)	IIC_Ack();
	else		IIC_NAck();
	
	return val;
}

uint8_t myiic_write_byte(uint8_t dev_addr,uint8_t val)
{
	IIC_Start();
	IIC_WriteByte(dev_addr& 0xfe);
	if(IIC_WaitAck())return 1;
	IIC_WriteByte(val);
	if(IIC_WaitAck())return 1;
	IIC_Stop();
	return 0;
}

uint8_t myiic_write_reg(uint8_t dev_addr,uint8_t reg_addr,uint8_t reg_val)
{
	IIC_Start();
	IIC_WriteByte(dev_addr& 0xfe);
	if(IIC_WaitAck())
	{
		return 1;
	}
	IIC_WriteByte(reg_addr);
	if(IIC_WaitAck())return 1;
	IIC_WriteByte(reg_val);
	if(IIC_WaitAck())return 1;
	IIC_Stop();
	
	return 0;
}

uint8_t myiic_read_reg(uint8_t dev_addr,uint8_t reg_addr)
{
	uint8_t reg_val;
	
	IIC_Start();
	IIC_WriteByte(dev_addr & 0xFE);
	if(IIC_WaitAck())return 1;
	IIC_WriteByte(reg_addr);
	if(IIC_WaitAck())return 1;
	
	IIC_Start();
	IIC_WriteByte(dev_addr|0x01);
	if(IIC_WaitAck())return 1;
	reg_val = IIC_ReadByte(0);	//������Ӧ��
	IIC_Stop();
	return reg_val;
}

uint8_t myiic_read_buffer(uint8_t dev_addr,uint8_t reg_addr,uint8_t len,uint8_t* pBuf)	//�ȶ����ֽ�
{
	uint8_t i;
	IIC_Start();
	IIC_WriteByte(dev_addr & 0xFE);
	if(IIC_WaitAck())
	{
		return 1;
	}
	IIC_WriteByte(reg_addr);
	if(IIC_WaitAck())return 1;
	
	IIC_Start();
	IIC_WriteByte(dev_addr|0x01);
	if(IIC_WaitAck())return 1;
	len--;
	for(i=0;i<len;i++)
	{
		pBuf[i] = IIC_ReadByte(1);	//����Ӧ��
	}
	pBuf[i] = IIC_ReadByte(0);	//������Ӧ��
	IIC_Stop();
	return 0;
}








