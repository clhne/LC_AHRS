#ifndef MYIIC_H
#define MYIIC_H

#include "sys.h"




#define IIC_SCL	PBout(6)
#define IIC_SDA	PBout(7)
#define IIC_SDAI	PBin(7)

//#define MYIIC_SCL	PBout(6)
//#define MYIIC_SDAO	PBout(7)
//#define MYIIC_SDAI	PBin(7)


//IO�����ú�
#define F_GPIO_Mode_AIN							0x00			//ģ������
#define F_GPIO_Mode_IN_FLOATING					0x04			//��������
#define F_GPIO_Mode_IPD							0x08			//��������
#define F_GPIO_Mode_IPU 							0x08			//�������� ͨ������ODR
#define F_GPIO_Mode_Out_PP 						0x00			//�������
#define F_GPIO_Mode_Out_OD 						0x04			//��©���
#define F_GPIO_Mode_AF_PP 							0x08			//�����������
#define F_GPIO_Mode_AF_OD 							0x0C			//���ÿ�©���

#define F_GPIO_Speed_IN							0x00			//����ģʽ
#define F_GPIO_Speed_10M							0x01			//10M
#define F_GPIO_Speed_2M							0x02			//2M
#define F_GPIO_Speed_50M							0x03			//50M



#define H_GPIO_SETMODEH_F(_port,_pin,_speed,_mode)		do{GPIO##_port->CRH&=~((u32)0x0F<<((_pin-8)*4));GPIO##_port->CRH|=(u32)(_mode|_speed)<<((_pin-8)*4);}while(0)
#define H_GPIO_SETMODEL_F(_port,_pin,_speed,_mode)		do{GPIO##_port->CRL&=~((u32)0x0F<<(_pin<<2));GPIO##_port->CRL|=(u32)(_mode|_speed)<<(_pin<<2);}while(0)

#define IIC_SCL_OUT()	do{H_GPIO_SETMODEH_F(B,10,F_GPIO_Speed_2M,F_GPIO_Mode_Out_PP);}while(0)
#define IIC_SDA_OUT()	do{H_GPIO_SETMODEH_F(B,11,F_GPIO_Speed_2M,F_GPIO_Mode_Out_PP);}while(0)
#define IIC_SDA_IN()	do{H_GPIO_SETMODEH_F(B,11,F_GPIO_Speed_IN,F_GPIO_Mode_IPU);}while(0)



//#define MYIIC_SDA_MODE_IN()	 do{H_GPIO_SETMODEL_F(B,7,F_GPIO_Speed_IN,F_GPIO_Mode_IPU);}while(0)
//#define MYIIC_SDA_MODE_OUT() do{H_GPIO_SETMODEL_F(B,7,F_GPIO_Speed_2M,F_GPIO_Mode_Out_PP);}while(0)





extern uint8_t myiic_fast_mode;
void myiic_init(void);
//uint8_t myiic_writebyte(uint8_t slave_addr,uint8_t c);
//uint8_t myiic_write_buffer(uint8_t slave_addr, void *buf,uint16_t len);
//uint8_t myiic_write_reg(uint8_t slave_addr,uint8_t reg_addr,uint8_t reg_val);
//uint8_t myiic_write_reg_buffer(uint8_t slave_addr,uint8_t reg_addr, void *buf,uint16_t len);

//uint8_t myiic_readbyte(uint8_t slave_addr);
//uint8_t myiic_read_buffer(uint8_t slave_addr,void *buf,uint16_t len);
//uint8_t myiic_read_reg(uint8_t slave_addr,uint8_t reg_addr);
//uint8_t myiic_read_reg_buffer(uint8_t slave_addr,uint8_t reg_addr,void *buf,uint16_t len);

void IIC_Init(void);
uint8_t myiic_write_byte(uint8_t dev_addr,uint8_t val);
uint8_t myiic_write_reg(uint8_t dev_addr,uint8_t reg_addr,uint8_t reg_val);
uint8_t myiic_read_reg(uint8_t dev_addr,uint8_t reg_addr);
uint8_t myiic_read_buffer(uint8_t dev_addr,uint8_t reg_addr,uint8_t len,uint8_t* pBuf);	//�ȶ����ֽ�

#endif







