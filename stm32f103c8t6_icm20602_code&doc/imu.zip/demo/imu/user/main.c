#include "sys.h"
#include "delay.h"
#include "usart.h"

#include "myiic.h"
#include "icm20602.h"
#include "spl06.h"
#include "ak8975.h"

#include "ano.h"
#include "spi.h"

int main()
{
	int16_t accadc[3];
	int16_t gyroadc[3];
	int16_t magadc[3];
	
	
	uint8_t t1=0;
	uint8_t TP_step = 0;
	float temp;
	float alt_3, height,height_offset = 0.0f;
	float press_height = 0.0f;
	
	float press_sum = 0.0f;
	uint8_t press_ok = 0;
	uint8_t press_cali_cnt = 0;
	uint8_t press_cali_ok = 0;
	
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	NVIC_SetVectorTable(NVIC_VectTab_FLASH,0);
	JTAG_Set(SWD_ENABLE);
	
	
	
	delay_init();
	usart1_init(500000);
	spi2_init();
	

	ak8975_init();
	icm20602_init();
	spl06_init();
	
	
	

	
	while(1)	
	{
		icm20602_get_accel_adc(accadc);
		icm20602_get_gyro_adc(gyroadc);
		ak8975_get_mag_adc(magadc);
		ak8975_start();
		
		if(++t1 == 11)	//110ms����ȡһ��
		{
			t1 = 0;
			switch(TP_step)
			{
				case 0:
					temp = spl06_get_temperature();
					spl06_start_P();
					TP_step = 1;
					break;
				case 1:
				case 2:
				case 3:
					press_sum += spl06_get_pressure();
					spl06_start_P();	
					TP_step ++;
					break;
				case 4:	
					press_sum += spl06_get_pressure();
					press_ok = 1;
					spl06_start_T();
					TP_step = 0;
					break;
					
			}
		}
		
		
		

		if(press_ok)	
		{
			
			press_sum /= 4;
			
			alt_3 = ( 101000 - press_sum ) / 1000.0f;
			height = 0.82f * alt_3 * alt_3 * alt_3 + 0.09f * ( 101000 - press_sum ) * 100.0f;
			press_ok = 0;
			press_sum = 0.0f;
			
			if(press_cali_ok)
			{
				press_height = height - height_offset;

			}
			else
			{
				height_offset += 0.1*height;
				if(++press_cali_cnt == 10)
				{
					press_cali_cnt = 0;
					press_cali_ok = 1;
				}
			}
			
			
		}		
			
		ANO_DT_Send_Status(temp,0,0,press_height,0,0);
		ANO_DT_Send_Sensor(accadc[0],accadc[1],accadc[2],gyroadc[0],gyroadc[1],gyroadc[2],magadc[0],magadc[1],magadc[2]);
		delay_ms(10);
		
	
	
	}
}

