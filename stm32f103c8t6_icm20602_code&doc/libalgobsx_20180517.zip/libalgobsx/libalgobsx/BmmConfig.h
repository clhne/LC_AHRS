#ifndef __BSX_BMMCONFIG_H__
#define __BSX_BMMCONFIG_H__
#include "GenericMagSpec.h"
BSX_S8 bmmconfig_setDefaultConfig(ts_magsensorspec *magSensorSpec, BSX_U8 SensorId);
#endif