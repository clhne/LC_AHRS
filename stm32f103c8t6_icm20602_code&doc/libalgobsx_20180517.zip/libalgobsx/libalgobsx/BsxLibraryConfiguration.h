#ifndef __BSXLIBRARYCONFIGURATION_H__
#define __BSXLIBRARYCONFIGURATION_H__
#include "BsxLibraryDataTypes.h"
BSX_U8 bsx_copyBytefromMemory(BSX_U8 *dst, BSX_U8 *src, BSX_S32 length);
BSX_U8 bsx_crc(BSX_U8* spec);
#endif