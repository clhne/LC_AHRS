#ifndef __BSX_BMACONFIG_H__
#define __BSX_BMACONFIG_H__
#include "GenericAccSpec.h"
BSX_S8 bmaconfig_setDefaultConfig(ts_accsensorspec *accSensorSpec, BSX_U8 SensorId);
#endif