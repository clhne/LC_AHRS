#ifndef __INVSQRT_H__
#define __INVSQRT_H__
#include "BsxLibraryDataTypes.h"
BSX_F32 invSqrtF(BSX_F32 x);
BSX_F64 invSqrt(BSX_F64 x);
#endif