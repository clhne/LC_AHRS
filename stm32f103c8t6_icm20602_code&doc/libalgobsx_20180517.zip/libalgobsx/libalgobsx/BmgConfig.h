#ifndef __BSX_BMGCONFIG_H__
#define __BSX_BMGCONFIG_H__
#include "GenericGyroSpec.h"
BSX_S8 bmgconfig_setDefaultConfig(ts_gyrosensorspec *gyroSensorSpec, BSX_U8 SensorId);
#endif