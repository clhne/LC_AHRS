#ifndef __TIME_H
#define __TIME_H
#include "sys.h"
void time_init(void);
u32 millis(void);
#endif
