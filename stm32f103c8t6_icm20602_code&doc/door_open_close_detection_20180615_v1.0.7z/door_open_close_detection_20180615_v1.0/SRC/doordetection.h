#ifndef __DOORDETECTION_H
#define __DOORDETECTION_H
void doordetection();

#endif