peak_trough;
monotonicity_detection;